import React, { useEffect, useState } from 'react';
import hmac from 'js-crypto-hmac';
import 'antd/dist/antd.css';
import './App.sass';

import { Button, message } from 'antd';
import { useHistory, useLocation, Switch, Route, Redirect } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

// @ts-ignore
// export const WsServiceContext: React.Context<WsService> = React.createContext(null);
// export const wsService = new WsService();

let deviceChar;


const handleConnect = () => {
  console.log('Requesting bluetooth device...');
  onRequestBluetoothDeviceButtonClick();
}

// uuid must be in lower case
const UUID_MAIN_GATT_SERVICE = '58af3dca-6fc0-4fa3-9464-74662f043a39';
const UUID_BATTERY_LEVEL = '00002a19-0000-1000-8000-00805f9b34fb';
const UUID_COMMAND = "58af3dca-6fc0-4fa3-9464-74662f043a3b";
const UUID_NOTIFY = "58af3dca-6fc0-4fa3-9464-74662f043a3a";

const DEVICE_NAME        = 'LB_B2sHvwZ3'
const DEVICE_KEY         = '733652384f763963' //HEX
const DEVICE_KEY_STRING  = '8301913364908882000' // string
const HMAC_FROM_KEY      = 'b7d08bb549c20a409e8ef7cc9e584067dd208f6f'
const HMAC_FIRST_14      = 'b7d08bb549c20a';
const HMAC_FIRST_14_2    = '93f22dfcb0bc22';



console.log('slice', 'd12157d436671efe28e2ca569fd993481bb36fec'.slice(0, 14))
console.log('parceInt', parseInt(DEVICE_KEY, 16))
console.log('length', '01505c84ff2f0099cf13d74d5b246c38eb6cf702'.length)

// SN: B2sHvwZ3
// KEY: 733652384F763963
// DEVICE_NAME: LB_B2sHvwZ3

// UUID fromString = UUID.fromString("58AF3DCA-6FC0-4FA3-9464-74662F043A39");
// Intrinsics.checkNotNull(fromString);
// SERVICE_B0_DATA = fromString;
// UUID fromString2 = UUID.fromString("58AF3DCA-6FC0-4FA3-9464-74662F043A3B");
// Intrinsics.checkNotNull(fromString2);
// B0_DATA_RX = fromString2;
// UUID fromString3 = UUID.fromString("58AF3DCA-6FC0-4FA3-9464-74662F043A3A");
// Intrinsics.checkNotNull(fromString3);
// B0_DATA_TX = fromString3;


const onRequestBluetoothDeviceButtonClick = async () => {
  console.log('Requesting any Bluetooth device...');

  // @ts-ignore
  const device = await navigator.bluetooth.requestDevice({
    filters: [{name: ['EL_B2sHvwZ3']}],
    optionalServices: ['58af3dca-6fc0-4fa3-9464-74662f043a39'],
    // acceptAllDevices: true
  })
  console.log('> Requested ' + device.name + ' (' + device.id + ')');
  console.log('---device', device);

  device.removeEventListener('gattserverdisconnected', () => {
    console.warn('---DISCONNECTED');
  });

  const gatt = await device.gatt.connect();
  console.log('GATT server connected, getting service...', gatt);

  const service = await gatt.getPrimaryService('58af3dca-6fc0-4fa3-9464-74662f043a39').catch(error => {
    console.log('Argh! ' + error);
  })

  console.log('GATT service', service);

  const notify = await service.getCharacteristic(UUID_NOTIFY).catch(error => {
    console.log('Argh! ' + error);
  });

  console.log('--- notify characteristic', notify);
  startNotifications(notify);

  const commandSend = await service.getCharacteristic(UUID_COMMAND).catch(error => {
    console.log('Argh! ' + error);
  });

  console.log('--- commandSend characteristic', commandSend);

  deviceChar = commandSend;



  //     .then(device => {
  //   console.log('> Requested ' + device.name + ' (' + device.id + ')');
  //   console.log('---device', device);
  //
  //   return device.gatt.connect()
  //       .then(server => {
  //         console.log('GATT server connected, getting service...', );
  //         return server.getPrimaryService(UUID_COMMAND);
  //       }).then(service => {
  //         console.log('Service found, getting characteristic...', service);
  //         return service.getCharacteristic(0xFFE1);
  //       }).catch(error => {
  //         console.log('Argh! ' + error);
  //       })
  // })
}


const  hexToBytes = (hex) => {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i !== bytes.length; i++) {
    bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
  }
  return bytes;
}

const handleCharacteristicValueChanged = (event) => {
  const value = new TextDecoder().decode(event.target.value);
  // console.warn('----event.target.value', event.target.value);
  console.log('----res value', value);
}

// Обработка полученных данных
const receive = (data) => {
  console.warn('---- ------ ----- receive', data);
}

function writeToCharacteristic(characteristic, data) {
  console.log('---try send data', data);
  console.log('---try to bytes', to_bytes(data));
  // characteristic.writeValue(new TextEncoder().encode(data));
  characteristic.writeValue(to_bytes(data));
}

function startNotifications(characteristic) {
  console.log('Starting notifications...');

  return characteristic.startNotifications().
  then(() => {
    console.log('Notifications started');
    // Добавленная строка
    characteristic.addEventListener('characteristicvaluechanged',
        handleCharacteristicValueChanged);
  });
}

const getHMAC = async (message, key) => {
  const hash = 'SHA-1';
  return await hmac.compute(key, message, hash)
}

const validateHMAC = async (message, key, mac) => {
  const hash = 'SHA-1';
  return hmac.verify(key, message, mac, hash)
}

const to_bytes = (hexString) => {
  return Uint8Array.from(hexString.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
}

const toHEX = (str) => {
  var result = '';
  for (var i=0; i<str.length; i++) {
    result += str.charCodeAt(i).toString(16);
  }
  return result;
}



const handleUnlock = async () => {
  const unlock = '01';
  const admId = '50';
  const time = Date.now().toString().slice(0, 10)
  const timeHEX = Number(time).toString(16);
  const mode = '00'; // unlock/wait/lock again (01=unlock only) (02=lock only)
  const messageData = unlock + admId + timeHEX + mode

  const encodedMessageData = to_bytes(messageData);
  const encodedByteKey = to_bytes(DEVICE_KEY);

  const hmac = await getHMAC(encodedMessageData, encodedByteKey);
  const isValid = await validateHMAC(encodedMessageData, encodedByteKey, hmac)
  if(isValid) {
    console.log('---HMAC VALID', isValid);
  }

  const decodedHEX = Buffer.from(hmac).toString('hex');
  const first13HMAC = decodedHEX.slice(0, 26);
  const first7MessageData = messageData + first13HMAC;

  // console.log('----first14HMAC', first13HMAC);
  // console.log('----first14HMAC len', first13HMAC.length);
  // console.log('----messageData', messageData);
  // console.log('----messageData len', messageData.length);
  // console.log('----sampleFrame', first7MessageData);
  // console.log('----sampleFrame len', first7MessageData.length);

  // console.log('---timeHEX', timeHEX);
  // console.log('---fullUnlockData', fullUnlockData);
  // console.log('---deviceChar', deviceChar);

  // const bytesPayload = new TextEncoder().encode(unlock + admId + timeHEX + mode)
  // console.log('---bytesPayload', bytesPayload);

  console.log('---deviceChar', deviceChar);

  if(deviceChar) {
    writeToCharacteristic(deviceChar, first7MessageData);
  }

}

const Root = () => {
  return <>
    <Button onClick={handleConnect}>Connect</Button>
    <Button>Disconnect</Button>
    <Button onClick={handleUnlock}>Send Unlock</Button>
  </>
}



function MainSwitchRouter() {
  return (
    <Switch>
      <Route exact path="/" component={Root} />
      <Redirect to="/" />
    </Switch>
  );
}

function App() {
  const dispatch = useDispatch();
  const location = useLocation();
  const history = useHistory();

  return (
      // <WsServiceContext.Provider value={wsService}>
        <div className="App">
          <MainSwitchRouter/>
        </div>
      // </WsServiceContext.Provider>
  );
}

export default App;
