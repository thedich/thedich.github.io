export class LocalStorageService {
  static setEntity(entityName: string, entity): void {
    localStorage.setItem(entityName, JSON.stringify(entity));
  }

  static getEntity(entityName: string): any {
    const jsonAsString: string | null = localStorage.getItem(entityName);
    return jsonAsString ? JSON.parse(jsonAsString) : null;
  }

  static removeEntity(entityName: string): any {
    localStorage.removeItem(entityName);
  }

  static saveEntityOnUnload(entityName: string, entity): void {
    window.addEventListener('unload', () => {
      LocalStorageService.setEntity(entityName, entity);
    });
  }
}
