import { API_BASE_URL } from './config';
import {LocalStorageService} from "./LocalStorageService";

export abstract class HttpService {
  private static async request(
    endpoint: string,
    { body, ...customConfig }: any = {},
    customResponseHandler = (res: any): any => {}
  ) {
    const headers = { 'Content-Type': 'application/json' };
    const config = {
      method: body ? 'POST' : 'GET',
      ...customConfig,
      headers: {
        ...headers,
        ...customConfig.headers,
      },
    };

    if (body) {
      config.body = JSON.stringify(body);
    }

    let data;

    try {
      const res = await fetch(API_BASE_URL + endpoint, config);

      const handledResponse = customResponseHandler(res);
      if (handledResponse) {
        return handledResponse;
      }

      if (res.status == 200 || res.status == 201) {
        data = await res.json();
      }

      if (res.ok) {
        return data;
      }

      const text = await res.text();

      throw new Error(text || res.statusText);
    } catch (err:any) {
      return Promise.reject(err.message || data);
    }
  }

  public static get(endpoint: string, customConfig: any = {}) {
    return this.request(endpoint, { ...customConfig, method: 'GET' });
  }

  public static post(endpoint: string, customConfig: any = {}) {
    return this.request(endpoint, { ...customConfig, method: 'POST' });
  }

  public static put(endpoint: string, customConfig: any = {}) {
    return this.request(endpoint, { ...customConfig, method: 'PUT' });
  }

  public static delete(endpoint: string, customConfig: any = {}) {
    return this.request(endpoint, { ...customConfig, method: 'DELETE' });
  }
}

export abstract class BigantoHttpService {
  private static async request(
    endpoint: string,
    { body, ...customConfig }: any = {},
    customResponseHandler = (res: any): any => {}
  ) {
    const headers = { 'Content-Type': 'application/json' };
    const config = {
      method: body ? 'POST' : 'GET',
      ...customConfig,
      headers: {
        ...headers,
        ...customConfig.headers,
      },
    };

    if (body) {
      config.body = JSON.stringify(body);
    }

    let data;

    const token = customConfig.token ? 'access_token=' + customConfig.token : 'access_token=';
    const extension = customConfig.extention ? '&extension=' + customConfig.extention : '';
    const defParams = '&client=filincam_server&client_version=0.0.1&lang=en';
    const apiPrefix = customConfig.apiPrefix ? customConfig.apiPrefix : '/processing_authorization/api/v1';

    try {
      const res = await fetch(
          API_BASE_URL + apiPrefix + endpoint + '?' + token + extension + defParams,
        config
      );

      const handledResponse = customResponseHandler(res);
      if (handledResponse) {
        return handledResponse;
      }

      if (res.status === 200 || res.status === 201) {
        data = await res.json();
      }

      if (res.status === 401) {
        throw new Error(res.status.toString());
      }

      if (res.ok) {
        return data;
      }

      const text = await res.text();

      throw new Error(text || res.statusText);
    } catch (err:any) {
      return Promise.reject(err.message || data);
    }
  }

  public static get(endpoint: string, customConfig: any = {}) {
    return this.request(endpoint, { ...customConfig, method: 'GET' });
  }

  public static post(endpoint: string, customConfig: any = {}) {
    return this.request(endpoint, { ...customConfig, method: 'POST' });
  }

  public static put(endpoint: string, customConfig: any = {}) {
    return this.request(endpoint, { ...customConfig, method: 'PUT' });
  }

  public static delete(endpoint: string, customConfig: any = {}) {
    return this.request(endpoint, { ...customConfig, method: 'DELETE' });
  }
}
