const version = require('../../package.json').version;
export const CLIENT_VERSION = version;
export const __DEV__ = process.env.NODE_ENV === 'development';

// const API_BASE_URL_DEV = 'http://10.42.0.1'; // WIFI local
// const WS_URL_DEV = '10.42.0.1'; // WIFI local

const WS_URL_DEV = '10.10.77.137'; // Camera lan
const API_BASE_URL_DEV = 'http://10.10.77.137'; // Camera lan

// const API_BASE_URL_DEV = 'http://10.10.77.80'; // devkit
// const WS_URL_DEV = '10.10.77.80'; // devkit

export const WS_PORT = 9092;
export const WS_URL = __DEV__ ? WS_URL_DEV : window.location.hostname;
export const API_BASE_URL = __DEV__ ? API_BASE_URL_DEV : window.location.origin;
