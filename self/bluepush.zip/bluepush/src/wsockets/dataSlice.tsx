import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { RootState } from '../store/store';
import { LocalStorageService } from '../api-utils/LocalStorageService';
import { HttpService } from "../api-utils/HttpService";

export const startLidarService = createAsyncThunk('lidar/startService', async () => {
  return await HttpService.post('/api/service/lidar-scanner/start');
});

export const stopLidarService = createAsyncThunk('lidar/stopService', async () => {
  return await HttpService.post('/api/service/lidar-scanner/stop');
});

export enum LIDAR_SERVICE_STATUS {
  RUN = 'run',
  STOP ='stop',
}

export enum SOCKET_STATUS {
  DISCONNECT = 'disconnect',
  CONNECT ='connect',
}

export enum LIDAR_STATUS {
  SCANNING ='scanning',
  READY ='ready'
}

const lidarSlice = createSlice({
  name: 'data',
  initialState: {
    lidarStatus: null,
    socketStatus: null,
    socketData: null,
  },
  reducers: {
    setLidarStatus(state, action) {
      return {
        ...state,
        lidarStatus: action.payload,
      };
    },

    setSocketStatus(state, action) {
      return {
        ...state,
        socketStatus: action.payload,
      };
    },

    setSocketData(state, action) {
      return {
        ...state,
        socketData: action.payload,
      };
    },
  },
  extraReducers: builder => {
    // @ts-ignore
    builder.addCase(startLidarService.fulfilled, (state, action) => {
      console.log('lidar status', action.payload);

      return {
        ...state,
        lidarStatus: LIDAR_SERVICE_STATUS.RUN
      };
    });

    // @ts-ignore
    builder.addCase(startLidarService.rejected, (state, action) => {
      console.log('lidar status rejected', action.payload);

      return {
        ...state,
        lidarStatus: LIDAR_SERVICE_STATUS.RUN
      }
    });

    // @ts-ignore
    builder.addCase(stopLidarService.fulfilled, (state, action) => {
      console.log('lidar status', action.payload);

      return {
        ...state,
        lidarStatus: LIDAR_SERVICE_STATUS.STOP
      };
    });

    // @ts-ignore
    builder.addCase(stopLidarService.rejected, (state, action) => {
      console.log('lidar status rejected', action.payload);

      return {
        ...state,
        lidarStatus: LIDAR_SERVICE_STATUS.STOP
      }
    });
  }
});

export default lidarSlice.reducer;
export const { actions } = lidarSlice;
export const getLidarStatus = (state: RootState) => state.data.lidarStatus;
export const getSocketStatus = (state: RootState) => state.data.socketStatus;
export const getSocketData = (state: RootState) => state.data.socketData;
