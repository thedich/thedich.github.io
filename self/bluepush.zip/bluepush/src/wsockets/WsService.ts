import store, { updateStore } from '../store/store';
import { WS_PORT, WS_URL } from '../api-utils/config';
import {actions, LIDAR_SERVICE_STATUS, SOCKET_STATUS} from "../wsockets/dataSlice";

const DELAY = 1500;
const MAX_BUSY_COUNTER = 5;
const WS_DISCONNECTED_TIMEOUT = 10000;

let mock;
export let distances;
export let intensities;

export enum LIDAR_COMMANDS {
  SCAN = 'scan',
  START = 'start',
  STOP = 'stop',
  SETTINGS ='settings',
  RESET ='reset',
}

export class WsService {
  ws: WebSocket | null = null;
  queue: string[];
  timerDescriptor: number | null = null;
  listeners: Array<(string) => void> = [];
  lastCommand: string = '';
  busyCounter: number = 0;
  deadTimerDescriptor: any = null;
  reconnect: boolean = false;

  constructor() {
    this.queue = [];
    this.init();
    setInterval(() => this.update(), 1500);
  }

  init(): void {
    store?.dispatch(actions.setSocketStatus(SOCKET_STATUS.DISCONNECT));
    this.ws = new WebSocket(`ws://${WS_URL}:${WS_PORT}`);
    this.ws.addEventListener('message', e => this.onMessage(e));

    this.ws.onopen = () => {
      updateStore();
      store?.dispatch(actions.setSocketStatus(SOCKET_STATUS.CONNECT));
      store.dispatch(actions.setLidarStatus(LIDAR_SERVICE_STATUS.RUN));
      console.log("socket open")

      this.reconnect = true;
    };
  }

  startDeadTimer(): void {
    this.deadTimerDescriptor = setTimeout(() => {
      store.dispatch(actions.setSocketStatus(SOCKET_STATUS.DISCONNECT));
    }, WS_DISCONNECTED_TIMEOUT);
  }

  send(): void {
    if (!this.queue.length) {
      return;
    }

    switch (this.ws?.readyState) {
      case WebSocket.OPEN: {
        if (this.deadTimerDescriptor === null) {
          this.startDeadTimer();
        }

        const command = this.queue.shift() || '';
        this.lastCommand = command;
        this.ws.send(command);
        setTimeout(() => {
          this.send();
        }, 100);
        return;
      }
      case WebSocket.CLOSED || WebSocket.CLOSING: {
        this.init();
        setTimeout(() => this.send, DELAY);
        return;
      }
      case WebSocket.CONNECTING: {
        setTimeout(() => this.send, DELAY);
        return;
      }
      default:
        this.init();
        setTimeout(() => this.send, DELAY);
        return;
    }
  }

  update(): void {
    this.queue.push(JSON.stringify({ id: 'state' }));
    this.send();
  }

  onMessage(event: any) {
    clearInterval(this.deadTimerDescriptor);
    this.deadTimerDescriptor = null;

    const eventData = JSON.parse(event.data);

    if (eventData && eventData.error === 'Scanner is busy' && this.busyCounter < MAX_BUSY_COUNTER) {
      this.busyCounter++;
      setTimeout(() => this.queue.unshift(this.lastCommand), 200);
      this.send();
      return;
    }

    if(eventData.scan?.distances_01) {
      distances = eventData.scan?.distances_01;
    }

    if(eventData.scan?.intensities_01) {
      intensities = eventData.scan?.intensities_01;
    }

    this.busyCounter = 0;
    this.listeners.forEach(listener => listener(eventData.state));
    store.dispatch(actions.setSocketData(eventData));
  }

  command(id, config): void {
    const command = {id, ...config};
    this.queue.push(JSON.stringify(command));
    this.send();
  }

  DEBUG_setSettings() {
    if (process.env.NODE_ENV !== 'development') {
      return;
    }
    this.onMessage({
      data: JSON.stringify({
        settings: {
          angular_resolution: 1800,
          first_angle: 95,
          last_angle: 280,
          first_step: 10,
          last_step: 20,
          scan_angle: 170,
          scan_steps: 50,
          min_distance: 10,
          max_distance: 60000,
        },
      }),
    });
  }

  DEBUG_setData() {
    if (process.env.NODE_ENV !== 'development') {
      return;
    }

    // mock scannerData 1080 by [x, y]
    const  randomInteger = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    mock = setInterval(() => {
      const fillMockData = Array(1080).fill(1)
      fillMockData.map((item, idx) => {
        fillMockData[idx] = randomInteger(0, 60000);
      })

      console.log('--fillMockData', fillMockData)

      this.onMessage({
        data: JSON.stringify({
          scannerData: fillMockData
        })
      })
    }, 25)
  }

  DEBUG_setStopData() {
    clearInterval(mock)
  }
}
