import { configureStore } from '@reduxjs/toolkit';
import { useDispatch } from 'react-redux';
import dataReducer from '../wsockets/dataSlice';
import { LocalStorageService } from '../api-utils/LocalStorageService';
import { someMiddleware } from './middlewares';

const store = configureStore({
  reducer: {
    data: dataReducer,
  },
  middleware: getDefaultMiddleware =>
      getDefaultMiddleware({
        immutableCheck: false,
        serializableCheck: false,
      }).concat([
      someMiddleware,
    ]),
});

store.subscribe(() => {
  // LocalStorageService.setEntity('auth', store.getState().auth);
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export const useAppDispatch = () => useDispatch<AppDispatch>();
export function updateStore() {
  const state = store.getState();

  // store.dispatch(fetchAuth());
  // console.log('updateStore', state)
}

export default store;
