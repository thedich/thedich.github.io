
import { AsyncThunk, AsyncThunkAction } from '@reduxjs/toolkit';

export const someMiddleware = ({ dispatch, getState }) => next => action => {
  //if (action.type === actions.update.type && action.payload.id === 'success') {
    // dispatch(sweepsActions.setSweepAfterSuccessScanning(action.payload.sweep));
  //}

  return next(action);
};

